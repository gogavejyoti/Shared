﻿(function ($) {
    $.fn.multiSelectDropdown = function (options) {
        const settings = $.extend({
            placeholder: 'Select options',
            data: [], 
            tooltip: false, 
            sortLabel: false, 
            disabled: false,
            onHide: function () { }, 
        }, options);

        this.each(function () {
            const $select = $(this);
            $select.hide(); // Hide the original select element

            // Create container
            const $container = $('<div>', { class: 'multi-select-container' });
            const $dropdown = $('<div>', { class: 'multi-select-dropdown' });
            const $input = $('<input>', {
                type: 'text',
                readonly: true,
                placeholder: settings.placeholder,
                class: 'multi-select-input',
                title: settings.tooltip ? settings.placeholder : '', // Initialize tooltip based on flag
                disabled: settings.disabled, // Set initial disabled state
            });
            const $optionsList = $('<ul>', { class: 'multi-select-options' });

            $dropdown.append($input, $optionsList);
            $container.append($dropdown);
            $select.after($container);

            // Function to update the input field and tooltip
            const updateInput = () => {
                const totalOptions = $optionsList.find('input.option-checkbox').length;
                const checkedOptions = $optionsList.find('input.option-checkbox:checked').length;

                let tooltipText = settings.tooltip ? settings.placeholder : ''; // Reset tooltip if flag is false

                if ($optionsList.find('input.select-all-checkbox').is(':checked')) {
                    $input.val('All');
                    if (settings.tooltip) tooltipText = 'All'; // Set tooltip for "All"
                } else if (checkedOptions > 0) {
                    const selected = $optionsList
                        .find('input.option-checkbox:checked')
                        .map((_, checkbox) => $(checkbox).next('span').text())
                        .get()
                        .join(', ');

                    $input.val(selected);
                    if (settings.tooltip) tooltipText = selected; // Set tooltip for selected items
                } else {
                    $input.val(settings.placeholder);
                    if (settings.tooltip) tooltipText = settings.placeholder; // Set tooltip to placeholder
                }

                // Update tooltip if flag is true
                if (settings.tooltip) {
                    $input.attr('title', tooltipText);
                }
            };

            // Sort labels alphabetically if sortLabel is true
            const sortData = (data) => {
                if (settings.sortLabel) {
                    return data.sort((a, b) => a.label.localeCompare(b.label));
                }
                return data;
            };

            // Render options with "Select All"
            const renderOptions = (data) => {
                $optionsList.empty();
                if (!settings.disabled) {
                    // Add "Select All" checkbox
                    const $selectAllLi = $('<li>', { class: 'select-all-li' });
                    const $selectAllCheckbox = $('<input>', {
                        type: 'checkbox',
                        class: 'select-all-checkbox',
                    }).on('change', function () {
                        const isChecked = $(this).is(':checked');
                        $optionsList.find('input.option-checkbox').prop('checked', isChecked);
                        updateInput();
                    });
                    const $selectAllLabel = $('<span>').text('Select All');
                    $selectAllLi.append($selectAllCheckbox, $selectAllLabel).on('click', function (e) {
                        if (!$(e.target).is('input')) $selectAllCheckbox.trigger('click');
                    });
                    $optionsList.append($selectAllLi);

                    // Sort the data if sortLabel is true
                    const sortedData = sortData(data);

                    // Add individual options
                    sortedData.forEach(item => {
                        const $li = $('<li>');
                        const $checkbox = $('<input>', {
                            type: 'checkbox',
                            value: item.value,
                            class: 'option-checkbox',
                        }).on('change', function () {
                            // Update "Select All" state
                            const totalOptions = $optionsList.find('input.option-checkbox').length;
                            const checkedOptions = $optionsList.find('input.option-checkbox:checked').length;
                            $selectAllCheckbox.prop('checked', totalOptions === checkedOptions);

                            updateInput();
                        });

                        const $label = $('<span>').text(item.label);
                        $li.append($checkbox, $label).on('click', function (e) {
                            if (!$(e.target).is('input')) $checkbox.trigger('click');
                        });
                        $optionsList.append($li);
                    });
                }
            };

            renderOptions(settings.data);

            // Toggle dropdown visibility
            $input.on('click', function (e) {
                if (settings.disabled) return;
                e.stopPropagation();
                $optionsList.toggle();
            });

            // Close dropdown on outside click
            $(document).on('click', function (e) {
                if (!$(e.target).closest('.multi-select-dropdown').length) {
                    if ($optionsList.is(':visible')) {
                        $optionsList.hide();
                        settings.onHide();
                    }
                }
            });

            // Prevent closing dropdown on click inside options
            $optionsList.on('click', function (e) {
                e.stopPropagation();
            });

            // Refresh data dynamically
            $select[0].refreshData = function (newData) {
                settings.data = newData;
                renderOptions(newData);
            };

            // Utility to get selected values
            $select[0].getSelectedValues = function () {
                if ($optionsList.find('input.select-all-checkbox').is(':checked')) {
                    return ['0']; // "All" selected
                }
                return $optionsList
                    .find('input.option-checkbox:checked')
                    .map((_, checkbox) => $(checkbox).val())
                    .get();
            };

            // Clear selected values
            $select[0].clearSelectedValues = function () {
                $optionsList.find('input.option-checkbox').prop('checked', false);
                $optionsList.find('input.select-all-checkbox').prop('checked', false);
                $input.val(settings.placeholder);
                if (settings.tooltip) {
                    $input.attr('title', settings.placeholder); // Reset tooltip to placeholder if enabled
                }
            };
            $select.data('previousSelectedIds', []);
            // Method to check if selection has changed
            $select[0].hasSelectionChanged = function () {
                const currentSelectedIds = $select[0].getSelectedValues(); // Get current selected values
                const previousSelectedIds = $select.data('previousSelectedIds');

                const selectionChanged = currentSelectedIds.length !== previousSelectedIds.length ||
                    currentSelectedIds.some(function (id) {
                        return previousSelectedIds.indexOf(id) === -1;
                    });

                // Update previous selection with the current selection
                $select.data('previousSelectedIds', currentSelectedIds);

                return selectionChanged;
            };

            $select[0].setDisabled = function (isDisabled) {
                settings.disabled = isDisabled;
                $input.prop('disabled', isDisabled);
                renderOptions(settings.data);
            };

            $select[0].selectValues = function (values) {
                $optionsList.find('input.option-checkbox').each(function () {
                    const isChecked = values.includes($(this).val());
                    $(this).prop('checked', isChecked);
                });
                const totalOptions = $optionsList.find('input.option-checkbox').length;
                const checkedOptions = $optionsList.find('input.option-checkbox:checked').length;
                $optionsList.find('input.select-all-checkbox').prop('checked', totalOptions === checkedOptions);
                updateInput();
            };

        });

        return this;
    };
})(jQuery);
