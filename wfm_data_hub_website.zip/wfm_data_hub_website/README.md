# WFM Data Hub — Circular Industry Hub

Open `index.html` in a modern browser. The hero background remains separate from all HTML overlays.

The central **THE HUB** element is surrounded in a circular arrangement by eight separate, editable HTML hexagons:
AMZ, Retail, Bank Finance, Travel, Technology, Healthcare, CME, and Insurance.

The smoke effect is removed. The hero carousel and text remain synchronized.


## Cinematic background motion
The hero carousel now uses subtle slow camera drift, ambient light movement, and a restrained light sweep to give the existing images a cinematic feel without changing the page layout. Motion respects the browser's `prefers-reduced-motion` accessibility setting. Open `index.html` in a local server or deploy the folder as usual.
