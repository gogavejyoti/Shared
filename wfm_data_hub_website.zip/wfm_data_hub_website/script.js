(() => {
  const slides = [...document.querySelectorAll(".hero-image")];
  const copies = [...document.querySelectorAll(".hero-copy")];
  const dots = [...document.querySelectorAll(".dot")];
  const label = document.getElementById("slideLabel");
  const names = ["DATA HUB", "CONNECTED DATA", "WORKFORCE ANALYTICS", "BUSINESS OUTCOMES"];
  const hero = document.querySelector(".hero");
  const hub = document.querySelector(".hero-sector-hub");
  let current = 0;
  let timer;

  function show(index) {
    current = (index + slides.length) % slides.length;
    slides.forEach((el, i) => el.classList.toggle("is-active", i === current));
    const slideStage = document.querySelector(".hero-slides");
    if (slideStage) {
      slideStage.classList.remove("motion-hub", "motion-cloud", "motion-globe", "motion-city");
      slideStage.classList.add(["motion-hub", "motion-cloud", "motion-globe", "motion-city"][current]);
    }
    copies.forEach((el, i) => {
      el.classList.toggle("active", i === current);
      el.setAttribute("aria-hidden", String(i !== current));
    });
    dots.forEach((el, i) => el.classList.toggle("active", i === current));
    label.textContent = `${String(current + 1).padStart(2, "0")} / 04   ${names[current]}`;
    if (hub) {
      hub.dataset.theme = String(current);
      hub.querySelectorAll(".sector").forEach((el, i) => {
        el.style.opacity = (current === 0 || i === current + 1 || i === current + 3) ? "1" : ".78";
      });
    }
  }
  function restart() {
    clearInterval(timer);
    timer = setInterval(() => show(current + 1), 4000);
  }
  document.getElementById("prevSlide").addEventListener("click", () => { show(current - 1); restart(); });
  document.getElementById("nextSlide").addEventListener("click", () => { show(current + 1); restart(); });
  dots.forEach(dot => dot.addEventListener("click", () => { show(Number(dot.dataset.slide)); restart(); }));
  // Keep rotation automatic even when pointer remains over the hero.
  show(0); restart();

  document.getElementById("mobileMenu").addEventListener("click", () => {
    const nav = document.querySelector(".vertical-nav");
    nav.classList.toggle("open");
  });
  document.querySelectorAll(".vertical-nav a").forEach(a => a.addEventListener("click", () => document.querySelector(".vertical-nav").classList.remove("open")));

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, {threshold: 0.12});
  document.querySelectorAll(".reveal").forEach(el => observer.observe(el));
})();